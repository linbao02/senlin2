./ore-miner   mine --address 你的sol钱包地址 --threads 0 --server ws://103.148.58.194:8989 --invcode  CJH8BR
pause

